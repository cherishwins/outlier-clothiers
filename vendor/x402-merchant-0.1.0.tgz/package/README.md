# x402-facilitator

> A working third-party x402 facilitator. USDC on Base. No Stripe. No KYC. Wallet-to-wallet.
> Production-deployed. Used by multiple live consumer apps. Open source.

**[Live](https://x402-facilitator.onrender.com)** · **[Hire us for x402 integration →](https://cal.com/cherishwins/x402)**

---

## What this is

A reference implementation of an [x402 protocol](https://www.x402.org) facilitator. x402 is the open standard, co-stewarded by [Coinbase and Cloudflare's x402 Foundation](https://www.coinbase.com/blog/coinbase-and-cloudflare-will-launch-x402-foundation), that lets HTTP servers charge for resources using stablecoin payments — settled in seconds, no accounts, no chargebacks, no card networks.

This repo is a **lightweight, self-hostable facilitator** that handles:
- `POST /pay` — creates a payment challenge (returns HTTP 402)
- `GET /pay/{id}` — checks payment status
- `POST /webhook` — payment verification
- `GET /buy/{product}` — preconfigured product flow
- `POST /verify-onchain` — on-chain tx verification on Base

## Why this exists

For production, most builders should use [Coinbase's CDP Facilitator](https://docs.cdp.coinbase.com/x402/welcome) — it's free up to 1,000 tx/month, multi-chain (Base, Polygon, Arbitrum, Solana, World), gas-sponsored, and OFAC-screened.

**This facilitator is for the case where you want:**
- Self-hosted infrastructure with zero third-party dependency
- A learning reference for how x402 actually works under the hood
- A starting point for chains or token configurations Coinbase doesn't yet support
- A facilitator you control end-to-end for compliance or geographic reasons

## Who's using it

This facilitator currently powers:
- **[outlier-clothiers](https://outlier-clothiers.vercel.app)** — direct-to-wallet clothing sales
- **[notaryton-bot](https://t.me/NotaryTON_bot)** — TON-side notarization with USDC settlement
- **[memescan](https://github.com/cherishwins/memescan-astro)** — paid rug-score lookups
- **[music](https://github.com/MobilityLink/music)** — paid AI music generation

## Deploy in 2 minutes

```bash
git clone https://github.com/cherishwins/x402-facilitator
cd x402-facilitator
# Push to your GitHub
git remote set-url origin https://github.com/YOU/x402-facilitator
git push -u origin main
```

Then on [Render](https://render.com/new): connect the repo and set the two required variables.

| Variable | Required | Notes |
|---|---|---|
| `PAYMENT_ADDRESS` | yes | Your Base address. No default — the service refuses to start without it. |
| `WEBHOOK_SECRET` | yes | `openssl rand -hex 32`. Rejected if left as `changeme`. |
| `ALLOWED_ORIGINS` | no | Comma-separated origins allowed to call it from a browser. |
| `BASE_RPC_URL` | no | Defaults to the public Base endpoint, which is rate-limited. |
| `MIN_CONFIRMATIONS` | no | Defaults to `2`. |

Both required variables fail closed at startup rather than falling back to a
default, because the failure mode of a default payment address is that money
lands somewhere nobody can spend it from.

## Endpoints

| Endpoint | Method | What it does |
|---|---|---|
| `/pay` | POST | Create payment challenge, returns HTTP 402 |
| `/support` | POST | Donation challenge — same rails, nothing owed in return |
| `/pay/{id}` | GET | Check payment status |
| `/webhook` | POST | Submit settlement proof. Signed **and** verified on-chain |
| `/verify-onchain` | POST | Check a transaction without settling it |
| `/buy/{product}` | GET/POST | Preconfigured product checkout |

## Quick usage

### Create a payment

```bash
curl -X POST https://x402-facilitator.onrender.com/pay \
  -H "Content-Type: application/json" \
  -d '{"item": "sweater", "amount": 100}'
```

Response (HTTP 402):
```json
{
  "status": "payment_required",
  "payment_id": "abc123",
  "amount": 100,
  "currency": "USDC",
  "network": "base",
  "pay_to": "0x14E6..."
}
```

### Quick buy (preconfigured products)

```bash
curl https://x402-facilitator.onrender.com/buy/seal
curl https://x402-facilitator.onrender.com/buy/music-track
curl https://x402-facilitator.onrender.com/buy/rug-score
```

### Settle after payment

`/webhook` requires an HMAC-SHA256 signature over the raw request body, in the
`X-Signature` header. The amount is **not** taken from the request — it comes
from the stored challenge and is checked against the chain.

```bash
BODY='{"payment_id":"abc123","tx_hash":"0x..."}'
SIG=$(printf '%s' "$BODY" | openssl dgst -sha256 -hmac "$WEBHOOK_SECRET" -hex | sed 's/.* //')

curl -X POST https://x402-facilitator.onrender.com/webhook \
  -H "Content-Type: application/json" \
  -H "X-Signature: $SIG" \
  -d "$BODY"
```

A request without a valid signature returns `401`. A signed request whose
transaction did not actually move the full amount to `PAYMENT_ADDRESS` returns
`402` with the reason.

## Default product catalog

| Product | Price (USDC) |
|---|---|
| sweater | $100 |
| hoodie | $80 |
| music-track | $0.50 |
| album-art | $0.10 |
| brand-kit | $0.25 |
| seal | $0.05 |
| rug-score | $0.10 |

Edit `main.py` to customize.

## Integration example

```js
// 1. Request the resource. A 402 carries the challenge.
const res = await fetch('https://your-x402.example.com/buy/sweater');
const challenge = await res.json();

// 2. Hand the user a payment request. `qr_data` is an EIP-681 URI naming the
//    token and the chain, so there is nothing for them to select by hand.
//    Render it as a QR code, or use it as a deep link:
window.location.href = challenge.qr_data;
// ethereum:0x8335…2913@8453/transfer?address=0x…&uint256=100000000

// 3. Settle from your SERVER, never the browser — the signature requires
//    WEBHOOK_SECRET, which must not ship to a client.
//    POST { payment_id, tx_hash } with an X-Signature header.
```

The `qr_data` URI targets the **token contract**, with the recipient as the
`transfer` argument. The arrangement that reads more naturally — recipient as
the target, amount in a `value` parameter — asks the wallet for native ETH
instead, and delivers no USDC at all.

## Verify it yourself — no facilitator required

A merchant charging for a resource should not have to route their customers'
money through a third party to find out whether they were paid. `merchant.py`
is the half of x402 that runs on **your** server, with no network calls and no
dependency on this service being up.

It works because an x402 payment is not a transfer — it is an EIP-3009
`TransferWithAuthorization` message the payer signs. The recipient, the amount,
the validity window and a one-time nonce all live *inside* the signature.
Change one byte and it no longer recovers to the payer. So whoever broadcasts
it cannot alter it, redirect it, hold it or replay it, and the tokens move from
payer to merchant in a single contract call.

```python
from merchant import payment_requirements, verify_authorization

MY_ADDRESS = "0x0e392132755757926F7965965A86B88880E90bca"

# 1. Quote the price. Return this body with HTTP 402.
body = payment_requirements(
    pay_to=MY_ADDRESS,
    amount_usdc=0.03,
    resource="https://example.com/api/v1/report",
    description="Situation report",
)

# 2. The payer retries with an X-PAYMENT header. Check it, offline.
result = verify_authorization(
    authorization=payload["authorization"],
    signature=payload["signature"],
    pay_to=MY_ADDRESS,          # required: compared against the signed message
    amount_usdc=0.03,           # required: compared against the signed value
    seen_nonces=already_served, # your own replay guard
)

if result["verified"]:
    serve(resource)             # then broadcast the authorization to settle
else:
    decline(result["reason"])
```

`pay_to` and `amount_usdc` are mandatory, and that is deliberate. An
authorization is a valid signature over *somebody's* payment — a merchant who
asks only "is this signed?" will serve a customer who paid a different address
entirely. The question worth asking is narrower: *is this signed, is it made
out to me, for at least what I charged, right now?*

## Sell something

`paywall.py` is the shop, and it is what makes the modules above a product
rather than a library. One route answers 402 with a price, takes a signed
authorization on the retry, verifies it offline and hands over the goods.

```
GET /paid/{slug}     402 with a price, or 200 with the thing
                     accepts x402 v2 (PAYMENT-SIGNATURE) and v1 (X-PAYMENT)
GET /ledger          every sale, publicly
GET /checkout/       the buyer's payment sheet
```

```bash
PAYMENT_ADDRESS=0x... WEBHOOK_SECRET=... uvicorn main:app
curl -s localhost:8000/paid/demo | node checkout/emit-typed-data.mjs --from 0x...
```

Three decisions in there are worth knowing about, because each is a place to
get it wrong.

**Verification proves the signature, not the balance.** A payer can sign a
perfectly valid authorization for money they do not have: the signature checks
out and the transfer reverts. For a digital resource the usual trade is to
serve anyway — the loss is one delivery, and the alternative is making every
buyer wait on a block. For a physical one it is not. So delivery timing is set
per resource, not per shop; a shop selling both a report and a hoodie would
otherwise have to pick the wrong answer for half its catalogue.

**The replay guard has to be local, and it has to be shared.** The token
contract burns the nonce on settlement and reverts a second attempt, which is
the real defence — but only once a transaction lands. Between accepting an
authorization and seeing it mined, only the shop's own record stands between
one payment and two deliveries.

That record is a file (`store.py`), not a set in memory, and the reason is
stronger than durability. A uvicorn worker is a process: `--workers 4` would
be four separate sets and four independent opinions about whether a nonce was
spent, so one authorization could buy the same thing four times from a shop
behaving exactly as configured. That is the ordinary case, not an unlucky
race. A `UNIQUE` constraint makes the database the single arbiter, and the
paywall *claims* a nonce in one statement rather than asking and then
recording — there is no gap for a second request to fit through.

Verified against a real server, not only in tests: buy something, kill the
process, start it again, replay the identical payment. The sale is still
there and the replay is refused.

```bash
LEDGER_PATH=data/sales.db   # the default; set to "memory" only for a demo
```

**`/ledger` withholds the authorizations.** An unsettled authorization is
payable by whoever holds it. Publishing one invites a stranger to broadcast it
whenever suits them, so the public ledger carries who paid what and when, and
not the instrument itself.

Nothing in the shop holds money. It holds the instruments that collect it, and
the merchant settles them from their own key.

## Settle it yourself, too

Settlement is the other half: broadcast the authorization and confirm the
transfer landed. That needs a chain connection and a little gas. `settle.py`
builds the transaction and stops there — it never opens a socket and never
learns a key, because who signs is the merchant's decision and deliberately not
ours.

```python
from settle import build_settlement

result = build_settlement(
    authorization=payload["authorization"],
    signature=payload["signature"],
    pay_to=MY_ADDRESS,              # same two arguments as verification,
    amount_usdc=0.03,               # for the same reason
    relayer=MY_HOT_WALLET,          # pays gas; has no claim on the funds
    tx_nonce=w3.eth.get_transaction_count(MY_HOT_WALLET),
    max_fee_per_gas=fees["maxFeePerGas"],
    max_priority_fee_per_gas=fees["maxPriorityFeePerGas"],
)

if result["ok"]:
    signed = my_signer.sign(result["transaction"])   # web3.py, a CDP server
    w3.eth.send_raw_transaction(signed.raw_transaction)  # wallet, a Ledger…
```

`build_settlement` verifies before it encodes, so you cannot build a
transaction for a payment that was not made out to you. The `to` of that
transaction is the **token contract**, never the merchant — the merchant is
named inside the calldata, by the payer, under their signature.

Which means the relayer's entire discretion is *whether* to broadcast and
*when*. It cannot redirect a cent, and it is not a party to the payment. So the
natural place to run it is the merchant's own server, submitting their own
sale.

Gas fields have no defaults on purpose: the right values come from the chain a
second before you send, and a stale hardcoded fee is either a transaction that
never mines or one that overpays silently forever.

## The same merchant, in TypeScript

`js/` is `merchant.py` and `settle.py` again, for a Next.js store, a Worker,
or anything with Web `Request` and `Response`. viem is its only dependency.
Nothing in it holds a key or opens a socket.

```bash
npm install x402-merchant viem
```

```ts
import { withX402, toBaseUnits } from 'x402-merchant';

export const GET = withX402(
  {
    payTo: process.env.PAY_TO!,
    amountUnits: toBaseUnits('0.03', 6),      // integers only; "0.03" never becomes a float
    resource: 'https://shop.example/report',
    description: 'Situation report',
  },
  async (request, payment) => Response.json({ report: '…', paidBy: payment.payer }),
  { claimNonce: nonce => ledger.claim(nonce) }, // one atomic INSERT with a UNIQUE nonce
);
```

No payment: a 402 that both client generations can read, x402 v1 in the
body and v2 in the `PAYMENT-REQUIRED` header. A payment on the retry, in
`PAYMENT-SIGNATURE` (v2) or `X-PAYMENT` (v1): parsed, verified offline
against *your* price and address, nonce claimed through your ledger, then
your handler runs. Malformed input from a stranger is a 402 with a reason,
never a 500. The pieces are exported separately when the wrapper is the
wrong shape: `paymentRequiredResponse`, `parsePayment`,
`verifyAuthorization`, `buildSettlement`.

The buyer's half is there too, dependency-free so it bundles for a
browser: `parseOffer` reads the 402, `buildTypedData` shapes what the wallet
signs (`eth_signTypedData_v4`, or `typedDataForViem` for a library signer),
and `paymentHeader` turns the signature into the `X-PAYMENT` header for the
retry.

```ts
import { parseOffer, buildTypedData, freshNonce, paymentHeader } from 'x402-merchant/client';

const quote = await fetch(url);                                   // 402
const offer = parseOffer(await quote.json());
const [from] = await ethereum.request({ method: 'eth_requestAccounts' });
const td = buildTypedData(offer, { from, nonce: freshNonce() });
const signature = await ethereum.request({ method: 'eth_signTypedData_v4', params: [from, JSON.stringify(td)] });
const paid = await fetch(url, { method: 'POST', headers: paymentHeader(td, signature) });
```

It is a port, and ports drift. `test_js_merchant.py` runs every accept and
every decline through both languages and asserts the answers match, reason
string for reason string, and that the settlement calldata both sides build
is byte-identical. `npm test` builds and runs the TypeScript suite;
`pytest` then drives the built CLI.

## The checkout

`checkout/` is the one screen the buyer sees: the item, the price, and a
button that says Buy. It turns a 402 response into a signed authorization the
two modules above already know how to verify and settle.

Two rules from the design are enforced rather than intended.

**Dollars, never plumbing.** The words *wallet*, *crypto*, *network*, *gas*
and the name of the token appear nowhere on screen — `test_checkout.py`
asserts it against the rendered text. The buyer is paying for a thing in
dollars; that it settles on a chain is ours to know.

**No float touches money.** `maxAmountRequired` is a uint256 as a decimal
string, and BigInt carries it end to end. At one particular amount the obvious
`Number(x) / 1e6` overcharges by a cent — there is a test naming that amount.

```bash
node --test checkout/payment.test.js   # the sheet's own logic
pytest test_checkout.py                # that same JS, against the verifier
```

The second of those is the one worth having. The JavaScript the browser really
runs builds the payload, Python signs it as a buyer's wallet would, and
`verify_authorization` is asked whether it would serve the resource. Nothing is
reimplemented on either side, so the two cannot quietly drift apart — which is
the failure that otherwise shows up as declined payments with no visible cause.

The signer is injected, not imported. In production it is an embedded wallet
made from an email login; the buyer never sees a key, a phrase or an address,
and never learns that one exists.

**Not built here:** the prepaid balance — the add-funds screen and the
withdraw screen. Holding a buyer's balance is a different activity with
different rules, and nothing in this repository does it.

## Architecture

```
x402-facilitator/
├── main.py                # FastAPI app: routes, payment state, verification
├── merchant.py            # Merchant-side verification. No network, no us.
├── paywall.py             # The shop: 402, verify, deliver, ledger.
├── settle.py              # Verified authorization -> unsigned transaction.
├── splits.py              # Who gets paid what. Pure integer arithmetic.
├── store.py               # The ledger as a file. Survives restarts and workers.
├── ontology.json          # Every entity, named once. Enforced, not decorative.
├── checkout/              # The payment sheet the buyer actually sees
│   ├── index.html         #   One screen: item, price, Buy.
│   ├── payment.js         #   Offer parsing, money, EIP-712 payload. No deps.
│   ├── payment.test.js    #   node --test
│   └── emit-typed-data.mjs#   Pipe a 402 body in, see what a buyer would sign.
├── test_main.py           # Settlement-path tests, mostly adversarial
├── test_ontology.py       # The ontology against the code, both directions
├── test_paywall.py        # Ways to get the goods without having paid
├── test_merchant.py       # Authorization tests, entirely adversarial
├── test_checkout.py       # The sheet's own JS against the verifier, end to end
├── test_settle.py         # Encoding checked twice, and what a relayer cannot do
├── test_store.py          # Durability, and twenty threads racing one nonce
├── test_splits.py         # Payout tests. The sums must come out exact.
├── requirements.txt       # FastAPI, uvicorn, httpx, pydantic, eth-account
├── requirements-dev.txt   # + pytest
├── render.yaml            # Render deployment config
└── .env.example           # PAYMENT_ADDRESS, WEBHOOK_SECRET, etc.
```

## Security posture

Two independent checks stand between a request and a payment marked settled,
and both are mandatory:

1. **An HMAC signature** over the raw request body proves the caller holds
   `WEBHOOK_SECRET`.
2. **The chain** proves the money moved, via the USDC `Transfer` log in the
   transaction receipt.

Neither is sufficient alone. A signature says who is asking, not that anyone
paid. A transaction hash says money moved, not that it was for this order.

What settlement verifies:

- ✅ Signature present and valid — a missing `X-Signature` is `401`, not a pass
- ✅ Transaction mined and not reverted
- ✅ At least `MIN_CONFIRMATIONS` deep
- ✅ Transfer emitted by the **USDC contract** — an arbitrary token does not count
- ✅ Recipient is `PAYMENT_ADDRESS`
- ✅ Amount is at least the challenge amount, taken from stored state rather than
  from the request body
- ✅ One transaction settles one payment — reuse returns `409`
- ✅ Re-settling a paid payment is idempotent, not a double credit

Still worth knowing:

- ⚠️ State is in-memory by default; a restart drops **pending** payments. Settled
  ones are recoverable from the chain. Set `SUPABASE_URL`/`SUPABASE_KEY` to persist.
- ⚠️ No rate limiting by default — put Cloudflare or a reverse proxy in front
- ⚠️ Free-tier Render sleeps after 15 min idle — Starter plan minimum for real use

```bash
pip install -r requirements-dev.txt
pytest
```

### Upgrading from 1.x

Three breaking changes, all of them closing holes:

1. `X-Signature` on `/webhook` is now **required**. Previously the signature was
   verified only when the header happened to be present, so omitting it skipped
   verification entirely and any caller could mark any payment paid.
2. `/webhook` no longer accepts `amount` or `sender` from the request body. The
   amount is read from the stored challenge and checked against the chain.
3. `PAYMENT_ADDRESS` and `WEBHOOK_SECRET` have no defaults and the service will
   not start without them.

## Need integration help?

If you want to add x402 to your app, API, or AI agent, we do this for a living. Our consumer apps prove the pattern works end-to-end — TON + Base, Telegram + browser, micropayments + larger purchases.

**Engagements:**
- 🛠️ **x402 integration sprint** — 1-2 weeks, your app gets paid endpoints. From $5,000.
- 🏗️ **Custom facilitator build** — self-hosted, multi-chain, your compliance needs. From $15,000.
- 🤝 **Strategic partnership** — ongoing dev partnership for x402-native product companies.

**[→ Book a 20-min scoping call](https://cal.com/cherishwins/x402)**

## License

MIT for the facilitator code. The reference implementation is free to use, fork, and adapt. Commercial integration consulting is a separate engagement.

---

*Built by [cherishwins](https://github.com/cherishwins). Used in production. Listed on the [x402 ecosystem page](https://www.x402.org/ecosystem) (pending submission).*
